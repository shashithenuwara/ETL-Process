CREATE TABLE Dim_Location (
    address_id INT PRIMARY KEY,
    street_number VARCHAR(10),
    street_name VARCHAR(200),
    city VARCHAR(100),
    country_name VARCHAR(200)
);
